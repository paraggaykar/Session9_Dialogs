package com.example.session9assignment2;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.NotificationCompat;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends Activity {

    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button)findViewById(R.id.buttonShow);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder Builder = new AlertDialog.Builder(MainActivity.this);

                Builder.setTitle("Confirm Delete.....");
                Builder.setMessage("Are you sure you want to Delete this?");
                Builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(getApplicationContext(), "You Say Yes...", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();//hide the dialog UI
                            }
                        });

                Builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                                Toast.makeText(getApplicationContext(), "You Say NO....", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();//hide the dialog UI
                            }
                        });


                AlertDialog alertDialog = Builder.create();
                alertDialog.show();

            }
        });
    }


}
