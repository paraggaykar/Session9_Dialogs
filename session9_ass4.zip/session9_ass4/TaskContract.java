package com.example.session9assignment4.session9assignment4;

import android.provider.BaseColumns;

/**
 * Created by trident on 7/6/16.
 */
public class TaskContract {

    public static final String DB_NAME = "MYINFODB";
    public static final int DB_VERSION = 1;

    public class TaskEntry implements BaseColumns {
        public static final String TABLE = "PersonalInfo";

        public static final String COL_name = "name";
        public static final String COL_phno = "phone_no";
        public static final String COL_dob = "date_of_birth";
    }
}
