package com.example.session9assignment4.session9assignment4;

/**
 * Created by trident on 7/6/16.
 */
public class TaskListAdapter {
    String name,phno,dob;

    public TaskListAdapter(String name, String phno, String dob) {
        this.name = name;
        this.phno = phno;
        this.dob = dob;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhno() {
        return phno;
    }

    public void setPhno(String phno) {
        this.phno = phno;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    @Override
    public String toString() {
        return "TaskListAdapter{" +
                "name='" + name + '\'' +
                ", phno='" + phno + '\'' +
                ", dob='" + dob + '\'' +
                '}';
    }
}
